<script>
	import LoginForm from './LoginForm.svelte';
</script>

<div class="flex flex-col items-center justify-center h-screen">
	<LoginForm></LoginForm>
</div>
