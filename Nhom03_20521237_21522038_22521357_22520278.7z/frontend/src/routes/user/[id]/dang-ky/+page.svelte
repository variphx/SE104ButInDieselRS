<script lang="ts">
	import type { PageServerData } from './$types';

	export let data: PageServerData;
</script>

<form method="POST" action="?/dang_ky">
	<label class="label">
		<span> Môn học mở </span>
		<select class="select" name="id_mon_hoc_mo">
			{#each data.mon_hoc_mos as mon_hoc_mo}
				<option value={mon_hoc_mo.id}>
					{mon_hoc_mo.mon_hoc.ten}
				</option>
			{/each}
		</select>
	</label>
</form>
