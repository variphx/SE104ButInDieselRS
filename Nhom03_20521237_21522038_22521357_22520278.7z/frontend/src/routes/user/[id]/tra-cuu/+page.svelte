<script lang="ts">
	import { enhance } from '$app/forms';
	import type { ActionData, PageServerData } from './$types';

	export let data: PageServerData;
	export let form: ActionData;
</script>

<form action="?/reload_on_hoc_ky" use:enhance>
	<input class="hidden" type="text" name="id_sinh_vien" value={data.id_sinh_vien} />

	<label class="label">
		<span> Học kỳ </span>
		<div class="grid grid-cols-[1fr_auto] gap-4">
			<select class="select" name="id_hoc_ky">
				{#each data.hoc_kys as hoc_ky}
					<option value={hoc_ky.id}>Học kỳ {hoc_ky.ten}, Năm học {hoc_ky.nam_hoc}</option>
				{/each}
			</select>

			<div class="flex flex-col items-center justify-center">
				<button class="btn variant-filled" type="submit"> Nhập </button>
			</div>
		</div>
	</label>
</form>

{#if form?.chi_tiet_dkmhs}
	<div class="table-container">
		<table class="table table-hover table-compact">
			<thead>
				<tr>
					<th>Mã chi tiết đăng ký</th>
				</tr>
			</thead>
			<tbody>
				{#each form?.chi_tiet_dkmhs as chi_tiet_dkmh}
					<tr>
						<td>
							{chi_tiet_dkmh.mon_hoc_mo.mon_hoc.ten}
						</td>
					</tr>
				{/each}
			</tbody>
		</table>
	</div>
{/if}
