<script lang="ts">
	import { AppRail, AppRailAnchor } from '@skeletonlabs/skeleton';
	import type { LayoutServerData } from './$types';
	import { page } from '$app/stores';

	interface Path {
		name: string;
		url: string;
	}

	export let data: LayoutServerData;

	const paths = [
		{
			name: 'Học phần đã đăng ký',
			url: `/user/${data.session.username}/tra-cuu`
		},
		{
			name: 'Đăng ký học phần',
			url: `/user/${data.session.username}/dang-ky`
		},
		{
			name: 'Tra cứu học phí',
			url: `/user/${data.session.username}/hoc-phi`
		}
	] satisfies Path[];
</script>

<div class="grid grid-cols-[auto_1fr]">
	<AppRail class="h-screen">
		{#each paths as path}
			<AppRailAnchor href={path.url} selected={$page.url.pathname === path.url}>
				{path.name}
			</AppRailAnchor>
		{/each}
	</AppRail>
	<slot></slot>
</div>
