export { matchers } from './matchers.js';

export const nodes = [
	() => import('./nodes/0'),
	() => import('./nodes/1'),
	() => import('./nodes/2'),
	() => import('./nodes/3'),
	() => import('./nodes/4'),
	() => import('./nodes/5'),
	() => import('./nodes/6'),
	() => import('./nodes/7'),
	() => import('./nodes/8'),
	() => import('./nodes/9'),
	() => import('./nodes/10'),
	() => import('./nodes/11'),
	() => import('./nodes/12'),
	() => import('./nodes/13'),
	() => import('./nodes/14'),
	() => import('./nodes/15'),
	() => import('./nodes/16'),
	() => import('./nodes/17'),
	() => import('./nodes/18'),
	() => import('./nodes/19'),
	() => import('./nodes/20'),
	() => import('./nodes/21'),
	() => import('./nodes/22')
];

export const server_loads = [2,3];

export const dictionary = {
		"/": [~5],
		"/login": [~6],
		"/user": [~7,[2]],
		"/user/admin": [11,[2,4]],
		"/user/admin/chuong-trinh-hoc": [12,[2,4]],
		"/user/admin/chuong-trinh-hoc/tao": [~13,[2,4]],
		"/user/admin/chuong-trinh-hoc/tra-cuu": [~14,[2,4]],
		"/user/admin/mon-hoc-mo/tao": [~18,[2,4]],
		"/user/admin/mon-hoc-mo/tra-cuu": [~19,[2,4]],
		"/user/admin/mon-hoc": [~15,[2,4]],
		"/user/admin/mon-hoc/tao": [~16,[2,4]],
		"/user/admin/mon-hoc/tra-cuu": [~17,[2,4]],
		"/user/admin/sinh-vien": [20,[2,4]],
		"/user/admin/sinh-vien/tao": [~21,[2,4]],
		"/user/admin/sinh-vien/tra-cuu": [~22,[2,4]],
		"/user/[id]": [8,[2,3]],
		"/user/[id]/dang-ky": [~9,[2,3]],
		"/user/[id]/tra-cuu": [~10,[2,3]]
	};

export const hooks = {
	handleError: (({ error }) => { console.error(error) }),

	reroute: (() => {})
};

export { default as root } from '../root.svelte';