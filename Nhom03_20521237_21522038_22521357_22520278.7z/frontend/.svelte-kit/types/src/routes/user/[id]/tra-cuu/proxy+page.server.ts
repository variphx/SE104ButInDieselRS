// @ts-nocheck
import { get_all_chi_tiet_dkmh_by_dkmh } from '$lib/model/chi_tiet_dkmh';
import { get_dang_ky_mon_hoc_by_id_sinh_vien_and_id_hoc_ky as get_dkmh_by_id_sinh_vien_and_id_hoc_ky } from '$lib/model/dkmh';
import { get_all_hoc_ky_of_sinh_vien } from '$lib/model/hoc_ky';
import { get_session } from '$lib/model/session';
import type { Actions, PageServerLoad } from './$types';

export const load = async ({ parent }: Parameters<PageServerLoad>[0]) => {
	const data = await parent();

	const id_sinh_vien = data.id_sinh_vien;

	const hoc_kys = await get_all_hoc_ky_of_sinh_vien(
		new URLSearchParams({ id: id_sinh_vien.toString() })
	);

	return {
		id_sinh_vien,
		hoc_kys
	};
};

export const actions = {
	reload_on_hoc_ky: async ({ request }) => {
		const data = await request.formData();
		console.log(data);

		const id_hoc_ky = data.get('id_hoc_ky')?.toString();
		const id_sinh_vien = data.get('id_sinh_vien')?.toString();

		if (!(id_hoc_ky && id_sinh_vien)) {
			throw new Error();
		}

		const dkmh = await get_dkmh_by_id_sinh_vien_and_id_hoc_ky(
			new URLSearchParams({
				id_sinh_vien,
				id_hoc_ky
			})
		);

		const chi_tiet_dkmhs = await get_all_chi_tiet_dkmh_by_dkmh(
			new URLSearchParams({
				id_dkmh: dkmh.id.toString()
			})
		);

		return {
			chi_tiet_dkmhs
		};
	}
} satisfies Actions;
