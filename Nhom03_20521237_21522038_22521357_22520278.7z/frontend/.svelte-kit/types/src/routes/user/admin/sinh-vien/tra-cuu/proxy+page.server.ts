// @ts-nocheck
import { get_sinh_vien_all } from '$lib/model/sinh_vien';
import type { PageServerLoad } from './$types';

export const load = async () => {
	const sinh_viens = await get_sinh_vien_all();

	return {
		sinh_viens
	};
};
;null as any as PageServerLoad;