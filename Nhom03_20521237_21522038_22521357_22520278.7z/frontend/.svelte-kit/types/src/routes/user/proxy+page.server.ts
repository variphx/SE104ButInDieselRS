// @ts-nocheck
import { get_session } from '$lib/model/session';
import { redirect } from '@sveltejs/kit';
import type { PageServerLoad } from './$types';

export const load = async ({ parent }: Parameters<PageServerLoad>[0]) => {
	const parent_data = await parent();
	const session_id = parent_data.session_id;
	const session = await get_session(session_id);
	redirect(302, `/user/${session.username}`);
};
