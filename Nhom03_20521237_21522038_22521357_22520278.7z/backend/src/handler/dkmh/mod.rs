use axum::{extract::State, response::IntoResponse, Json, Router};
use diesel::prelude::*;

use crate::{context::Context, models::NewDKMH};

pub fn router() -> Router<Context> {
    Router::new().route("/post", axum::routing::post(post))
}

// async fn get() -> impl IntoResponse {
//     todo!()
// }

async fn post(
    State(mut context): State<Context>,
    Json(values): Json<Vec<NewDKMH>>,
) -> impl IntoResponse {
    use crate::schema::dkmh::dsl::*;

    diesel::insert_into(dkmh)
        .values(values)
        .execute(&mut context.db())
        .unwrap();
}
