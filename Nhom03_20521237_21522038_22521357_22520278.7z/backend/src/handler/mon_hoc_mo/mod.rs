use axum::{extract::State, response::IntoResponse, Json, Router};
use diesel::prelude::*;

use crate::{context::Context, models::NewMonHocMo};

mod all;

pub fn router() -> Router<Context> {
    Router::new()
        .route("/post", axum::routing::post(post))
        .nest("/all", all::router())
}

// #[derive(Deserialize)]
// struct Params {
//     id: i32,
// }

// async fn get() -> impl IntoResponse {}

async fn post(
    State(mut context): State<Context>,
    Json(value): Json<NewMonHocMo>,
) -> impl IntoResponse {
    use crate::schema::mon_hoc_mo::dsl::*;

    diesel::insert_into(mon_hoc_mo)
        .values(&value)
        .execute(&mut context.db())
        .expect("Error inserting into mon_hoc_mo");
}
