drop table que_quan;
