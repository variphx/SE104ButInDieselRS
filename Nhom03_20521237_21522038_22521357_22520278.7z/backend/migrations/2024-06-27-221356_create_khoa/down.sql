drop table khoa;
