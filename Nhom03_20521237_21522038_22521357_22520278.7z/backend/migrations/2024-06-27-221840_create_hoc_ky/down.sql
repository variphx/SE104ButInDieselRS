drop table hoc_ky;
