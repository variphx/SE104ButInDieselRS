drop table mon_hoc_mo;
