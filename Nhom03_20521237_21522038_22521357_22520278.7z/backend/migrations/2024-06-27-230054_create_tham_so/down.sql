drop table tham_so;
