drop table mon_hoc;
