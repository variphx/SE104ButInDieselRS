drop table sinh_vien;
