drop table chi_tiet_dkmh;
