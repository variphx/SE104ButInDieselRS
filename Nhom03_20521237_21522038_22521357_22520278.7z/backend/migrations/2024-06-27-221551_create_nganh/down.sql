drop table nganh;
