drop table doi_tuong;
